import SwiftUI

struct College {
    let Name: String
    let CName: String
    let Color: String
    let color: String
    let Founder: String
    let Representative: String
    let Dean: String
    let Choose: String
}

extension College {
    static let demoCollege = College(Name: "Gryffindor", CName: "葛來分多", Color: "Gryffindor_color", color: "紅色、金色", Founder: "高錐客・葛來分多", Representative: "金獅", Dean: "麥米奈娃", Choose: "勇氣、氣魄和騎士精神")
}

struct College_Detail: View {
    let Colleges: College
    var body: some View {
        ZStack(alignment: .leading){
            Image(Colleges.Color)
                .resizable()
                .ignoresSafeArea()
                .blur(radius: 2, opaque: true)
            VStack{
                Rectangle()
                    .foregroundColor(Color.clear)
                    .overlay {
                        Glassmorphism(GlassWidth: 375, Glassheight: 160)
                        HStack(spacing: 0){
                            Image(Colleges.Name)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 120)
                            VStack{
                                Text(Colleges.CName)
                                    .font(.custom("XiaolaiSC-Regular", size: 30))
                                VStack(alignment: .leading,spacing: 0){
                                    Text("院創立者："+Colleges.Founder)
                                        .font(.custom("XiaolaiSC-Regular", size: 17))
                                    Text("院代表物："+Colleges.Representative)
                                        .font(.custom("XiaolaiSC-Regular", size: 17))
                                    Text("學院顏色："+Colleges.color)
                                        .font(.custom("XiaolaiSC-Regular", size: 17))
                                    Text("學院院長："+Colleges.Dean)
                                        .font(.custom("XiaolaiSC-Regular", size: 17))
                                    Text("學生特質："+Colleges.Choose)
                                        .font(.custom("XiaolaiSC-Regular", size: 17))
                                }
                            }
                        }
                    }
                    .cornerRadius(30)
                
            }
        }
    }
}

#Preview {
    College_Detail(Colleges: .demoCollege)
}
