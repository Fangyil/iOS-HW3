import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView{
            college(GlassWidth: 180, GlassHeight: 300)
                .tabItem {
                    Image(systemName: "graduationcap.fill")
                    Text("About Colleges")
                }
                .toolbarBackground(.visible, for: .tabBar)
            Places()
                .tabItem {
                    Image(systemName: "building.columns.fill")
                    Text("Where to play")
                }
                .toolbarBackground(.visible, for: .tabBar)
            MySelf()
                .tabItem {
                    Image(systemName: "person.fill")
                    Text("About Myself")
                }
                .toolbarBackground(.visible, for: .tabBar)
            HomePage()
                .tabItem {
                    Image(systemName: "house.lodge.fill")
                    Text("Hogwats school")
                }
        }
    }
}

#Preview {
    ContentView()
}
