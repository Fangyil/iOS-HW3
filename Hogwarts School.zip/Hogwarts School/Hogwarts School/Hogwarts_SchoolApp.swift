import SwiftUI

@main
struct Hogwarts_SchoolApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
