import SwiftUI
import AVFoundation
import AVKit

func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
   try? AVAudioSession.sharedInstance().setCategory(.playback)
   return true
}

struct HomePage: View {
    @State private var animateGradient : Bool = false
    @State private var showingOptions = false
    @State private var selection = "Hedwigs Theme"
    @State private var AudioisPlay = false
    @State private var Widthvalue : CGFloat = 350
    @State private var Heightvalue : CGFloat = 100
    @State var dates: Set<DateComponents> = []
    @Environment(\.calendar) var calendar
    @Environment(\.timeZone) var timeZone
    @State private var isPresenting = false
    @State private var audioplayer = AVPlayer(url: Bundle.main.url(forResource: "Hedwigs Theme", withExtension: "mp3")!)
    let player = AVPlayer()
    let url = Bundle.main.url(forResource: "Introduce", withExtension: "mp4")!
    var stepHeight : CGFloat = 10
    var dateRange: Range<Date> {
        let start = calendar.date(from: DateComponents(
            timeZone: timeZone, year: 2024, month: 7, day: 18))!
        let end = calendar.date(from: DateComponents(
            timeZone: timeZone, year: 2024, month: 7, day: 31))!
        return start ..< end
        }
    
    var body: some View {
        let bgGradient = LinearGradient(colors: [Color(red: 124/255, green: 175/255, blue: 181/255), Color(red: 68/255, green: 87/255, blue: 120/255)], startPoint: animateGradient ? .top : .bottom, endPoint: animateGradient ? .bottom : .top)
        
        List{
            Section(header: Text("主題曲")){
                Toggle(selection, isOn: $AudioisPlay)
                    .onChange(of: AudioisPlay) { oldValue, newValue in
                        if newValue {
                            audioplayer.play()
                        } else {
                            audioplayer.pause()
                        }
                    }
                Button(action: {
                    showingOptions = true
                    if(AudioisPlay){
                        AudioisPlay.toggle()
                    }
                }) {
                    Text("Which Do You Wanna Listen ?")
                        .font(.custom("JMH Mummy Fill", size: 15))
                }
                .confirmationDialog("Choose A Song", isPresented: $showingOptions, titleVisibility: .visible) {
                    Button("Hedwigs Theme") {
                        selection = "Hedwigs Theme"
                        audioplayer = AVPlayer(url: Bundle.main.url(forResource: "Hedwigs Theme", withExtension: "mp3")!)
                    }
                    Button("Potter Waltz") {
                        selection = "Potter Waltz"
                        audioplayer = AVPlayer(url: Bundle.main.url(forResource: "PotterWaltz", withExtension: "mp3")!)
                    }
                    Button("The Flying Car") {
                        selection = "The Flying Car"
                        audioplayer = AVPlayer(url: Bundle.main.url(forResource: "TheFlyingCar", withExtension: "mp3")!)
                    }
                    Button("Gilderoy Lockhart") {
                        selection = "Gilderoy Lockhart"
                        audioplayer = AVPlayer(url: Bundle.main.url(forResource: "GilderoyLockhart", withExtension: "mp3")!)
                    }
                }
            }
            Section(header: Text("霍格華茲的傳承")) {
                Stepper( value: $Heightvalue, in: 100...340, step: stepHeight){
                    Text("調整影片大小")
                }
                VideoPlayer(player: AVPlayer(url: url))
                    .scaledToFit()
                    .frame(width: Widthvalue, height: Heightvalue)
            }
            Section(header: Text("回覆入學通知日期（複選）")) {
                MultiDatePicker("Select your preferred dates", selection: $dates, in: dateRange)
                    .colorInvert()
                    .colorMultiply(Color(red: 115/255, green: 135/255, blue: 114/255))
            }
            Button(action: {
                isPresenting.toggle()
            }) {
                Text("WELCOME TO HOGWARTS SCHOOL!")
                    .font(.custom("JMH Mummy Fill", size: 14))
                    .foregroundStyle(Color(red: 133/255, green: 113/255, blue: 122/255))
            }
            .fullScreenCover(isPresented: $isPresenting,
                             onDismiss: didDismiss){
                VStack{
                    Image("letter")
                        .resizable()
                        .scaledToFit()
                }
                .onTapGesture {
                    isPresenting.toggle()
                }
                .frame(maxWidth: .infinity,maxHeight: .infinity)
                .background(Color(red: 254/255, green: 252/255, blue: 243/255))
                .ignoresSafeArea(edges: .all)
            }
        }
        .scrollContentBackground(.hidden)
        .background(bgGradient.animation(Animation.linear(duration: 5.0).repeatForever(autoreverses: true), value: animateGradient))
        .ignoresSafeArea()
        .onAppear {
            animateGradient.toggle()
        }
    }
    func didDismiss() {/* Handle the dismissing action.*/}
}

#Preview {
    HomePage()
}
