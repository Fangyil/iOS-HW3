import SwiftUI
import PhotosUI

struct MySelf: View {
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var image: Image?
    @State private var name = ""
    @State private var Sexual: Double = 0
    @State private var Birthday = Date()
    @State private var bgColor = Color.brown
    @State private var LuckyNumber = ""
    @State private var showAlert = false
    @State private var alertTitle = ""
    @State private var show = false
    @State var animationed = true
    @State private var CollegesColor = ""
    @FocusState private var NameIsFocused: Bool
    @FocusState private var LuckyNumberIsFocused: Bool
    
    var body: some View {
        NavigationStack{
            ZStack{
                if(show){
                    Image(CollegesColor)
                        .resizable()
                        .scaledToFill()
                        .ignoresSafeArea()
                        .blur(radius: 3)
                }else{
                    Image("mist")
                        .resizable()
                        .blur(radius: 3)
                        .ignoresSafeArea()
                }
                Form{
                    Group{
                        HStack{
                            Spacer()
                            Circle()
                                .stroke(lineWidth: 6)
                                .foregroundStyle(Gradient(colors: [
                                    Color(red: 254/255, green: 235/255, blue: 152/255),
                                    Color(red: 202/255, green: 171/255, blue: 98/255)
                                ]))
                                .frame(width: 180)
                                .overlay {
                                    image?
                                        .resizable()
                                        .scaledToFill()
                                        .clipShape(Circle())
                                }
                                .toolbar {
                                    PhotosPicker(
                                        selection: $selectedPhoto,
                                        matching: .images
                                    ) {
                                        Image(systemName: "pencil")
                                    }
                                }
                                .task(id: selectedPhoto) {
                                    image = try? await selectedPhoto?.loadTransferable(type: Image.self)
                                }
                            Spacer()
                        }
                        HStack{
                            Spacer()
                            Text("姓名")
                                .padding(.trailing)
                            TextField("Your Name", text: $name)
                                .textFieldStyle(.roundedBorder)
                                .overlay(.blue, in: .rect(cornerRadius: 9).stroke(lineWidth: 3))
                                .padding(.leading)
                                .focused($NameIsFocused)
                                .onTapGesture {
                                    NameIsFocused = false
                                }
                        }
                        HStack{
                            Spacer()
                            Text("性別")
                                .padding(.trailing)
                            Slider(value: $Sexual, in: 0...10, step: 1) {
                                Text("age")
                            } minimumValueLabel: {
                                Text("男")
                            } maximumValueLabel: {
                                Text("女")
                            }
                            .tint(.orange)
                            .padding(.leading)
                        }
                        HStack{
                            Spacer()
                            DatePicker("生日", selection: $Birthday, in: ...Date(), displayedComponents: .date)
                        }
                        HStack{
                            Spacer()
                            ColorPicker("幸運色", selection: $bgColor)
                            Rectangle()
                                .foregroundColor(bgColor)
                                .frame(width: 195, height: 25)
                                .cornerRadius(15)
                        }
                        HStack{
                            Spacer()
                            Text("幸運數")
                            TextField("Lucky Number", text: $LuckyNumber)
                                .textFieldStyle(.roundedBorder)
                                .keyboardType(.numberPad)
                                .overlay(.blue, in: .rect(cornerRadius: 9).stroke(lineWidth: 3))
                                .padding(.leading)
                                .focused($LuckyNumberIsFocused)
                                .onTapGesture {
                                    LuckyNumberIsFocused = false
                                }
                        }
                        HStack{
                            Spacer()
                            Button {
                                showAlert = true
                                alertTitle = ["Gryffindor", "Hufflepuff", "Ravenclaw", "Slytherin"].randomElement()!
                            } label: {
                                ZStack{
                                    Image("ClassificationHat")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 250)
                                    //                                Group{
                                    //                                    Image(systemName: "cloud.fill")
                                    //                                        .resizable()
                                    //                                        .frame(width: 120, height: 60)
                                    //                                        .foregroundColor(.gray)
                                    //                                    Text("準備好了嗎？")
                                    //                                        .foregroundStyle(.black)
                                    //                                        .font(.custom("XiaolaiSC-Regular", size: 18))
                                    //                                        .offset(x: 5, y:10)
                                    //                                }
                                    //                                .offset(x:90, y:-90)
                                    //                                .transition(.opacity)
                                    //                                .onAppear()
                                }
                            }
                            .alert(alertTitle, isPresented: $showAlert) {
                                Button("Yes") {
                                    show = true
                                    if(alertTitle=="Gryffindor"){
                                        CollegesColor = "Gryffindor_color"
                                    }
                                    if(alertTitle=="Hufflepuff"){
                                        CollegesColor = "Hufflepuff_color"
                                    }
                                    if(alertTitle=="Ravenclaw"){
                                        CollegesColor = "Ravenclaw_color"
                                    }
                                    if(alertTitle=="Slytherin"){
                                        CollegesColor = "Slytherin_color"
                                    }
                                    
                                }
                                Button("No", role: .cancel) { }
                            }message: {
                                Text("你滿意這個結果嗎？")
                            }
                            Spacer()
                        }
                    }
                    .listRowBackground(Glassmorphism(GlassWidth: .infinity, Glassheight: 800))
                }
            }
            .scrollContentBackground(.hidden)
        }
    }
}

#Preview {
    MySelf()
}
