import SwiftUI
import MapKit

struct Site{
    let Name : String
    let CName : String
}

extension CLLocationCoordinate2D {
    static let KingsCrossStation = CLLocationCoordinate2D(latitude: 51.531663439803935, longitude: -0.12357634501915034)
    static let Platform9¾ = CLLocationCoordinate2D(latitude: 51.532087250559705, longitude: -0.12388748123399027)
}

struct Places: View {
    @State var sitesL : [Site] = [
        Site(Name: "The Burrow", CName: "洞穴屋"), Site(Name: "Godric's Hollow", CName: "高錐克洞"),Site(Name: "Little Hangleton", CName: "小漢果頓"), Site(Name: "Little Whinging", CName: "小惠因區"), Site(Name: "Malfoy Manor", CName: "馬份莊園"), Site(Name: "Shell Cottage", CName: "貝殼居"), Site(Name: "Spinner's End", CName: "紡紗街"), Site(Name: "No.12, Grimmauld Place", CName: "古里某街12號")
    ]
    @State var sitesD : [Site] = [
        Site(Name: "Diagon Alley", CName: "斜角巷"), Site(Name: "Flourish and Blotts", CName: "華麗與污痕書店"), Site(Name: "Knockturn Alley", CName: "夜行巷"), Site(Name: "Borgin and Burkes", CName: "波金與伯克氏商店"), Site(Name: "The Leaky Cauldron", CName: "破釜酒吧"), Site(Name: "Magical Menagerie", CName: "奇獸動物園"), Site(Name: "Ollivanders", CName: "奧利凡德魔杖店"), Site(Name: "Scribbulus shop", CName: "斜角巷文具用品店"), Site(Name: "Twilfitt and Tattings", CName: "何紳與華邊"), Site(Name: "Weasley's Wizard Wheezes", CName: "衛斯理兄弟巫師法寶店"), Site(Name: "Slug & Jiggers Apothecary", CName: "藥房"), Site(Name: "Stalls", CName: "小攤檔")
    ]
    @State var sitesH : [Site] = [
        Site(Name: "Hogsmeade", CName: "活米村"), Site(Name: "Dervish and Banges", CName: "德維與班吉禮品店"), Site(Name: "Gladrags Wizardwear", CName: "風雅氏高級巫師服飾店"), Site(Name: "Honeydukes Sweetshop", CName: "蜂蜜公爵糖果店"), Site(Name: "Hogsmeade Station", CName: "活米村站"), Site(Name: "The Hog's Head", CName: "豬頭酒吧"), Site(Name: "Madam Puddifoot's Tea", CName: "泥腳夫人茶館"), Site(Name: "Hogsmeade Post Office", CName: "活米村郵局"), Site(Name: "Scrivenshaft's Quill Shop", CName: "寫字人羽毛筆店"), Site(Name: "Shrieking Shack", CName: "尖叫屋"), Site(Name: "The Three Broomsticks", CName: "三根掃帚旅館"), Site(Name: "Zonko's Joke Shop", CName: "桑科的惡作劇商店")
    ]
    @State var sitesG : [Site] = [
        Site(Name: "Azkaban Prisoner", CName: "阿茲卡班監獄"), Site(Name: "MACUSA", CName: "美國魔法部"), Site(Name: "Ministry of Magic", CName: "英國魔法部"), Site(Name: "Nurmengard Prisoner", CName: "紐蒙迦德監獄"), Site(Name: "King's Cross Station", CName: "國王十字車站"), Site(Name: "St Mungo's Hospital for Magical Maladies and Injuries", CName: "聖蒙果魔法疾病與傷害醫院"), Site(Name: "Platform 9¾", CName: "9¾月台")
    ]
    @State private var isExpanded = true
    @State private var showingOptions = false
    private var region: MKCoordinateRegion {
            MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 51.53161004604319, longitude: -0.12359780269004013), latitudinalMeters: 1000, longitudinalMeters: 1000)
        }
    
    var body: some View {
        ZStack{
            Image("Hogwarts_Places")
                .resizable()
//              .scaledToFill()
                .ignoresSafeArea()
            Form{
                DisclosureGroup {
                    ForEach($sitesL, id: \.Name) { $sites in
                        SiteView(site: $sites)
                    }
                }label: {
                    Text("住宅")
                }
                DisclosureGroup {
                    ForEach($sitesD, id: \.Name) { $sites in
                        SiteView(site: $sites)
                    }
                }label: {
                    Text("斜角巷")
                }
                DisclosureGroup {
                    ForEach($sitesH, id: \.Name) { $sites in
                        SiteView(site: $sites)
                    }
                }label: {
                    Text("活米村")
                }
                DisclosureGroup(isExpanded: $isExpanded) {
                    ForEach($sitesG, id: \.Name) { $sites in
                        SiteView(site: $sites)
                    }
                }label: {
                    Text("關於政府")
                }
            }
            
            if(showingOptions){
                Map(initialPosition: .region(region)){
                    Annotation("King's Cross Station", coordinate: .KingsCrossStation) {
                        Image(systemName: "crown")
                            .foregroundColor(.white)
                            .padding(5)
                            .background {
                                Circle()
                                    .foregroundStyle(.red)
                            }
                    }
                    Marker("Platform 9¾", coordinate: .Platform9¾)
                }
            }
            
            Button {
                if(showingOptions == true){
                    showingOptions = false
                }else{
                    showingOptions = true
                }
            } label: {
                Image(systemName: "globe.europe.africa.fill")
                    .resizable()
                    .foregroundColor(.brown)
                    .scaledToFit()
                    .frame(width: 40)
            }
            .offset(x:-150,y:-380)
        }
        .scrollContentBackground(.hidden)
    }
}

#Preview {
    Places()
}

struct SiteView: View {
    @Binding var site : Site
    @State private var show = false
    @State private var mark = false
    
    var body: some View {
        HStack{
            Text(site.Name)
                .font(.custom("JMH Mummy Fill", size: 15))
                .contextMenu{
                    Button(action: {
                        if(show){
                            show = false
                        }else{
                            show = true
                        }
                    }) {
                        Text(site.CName)
                        if(show){
                            Image(systemName: "suit.heart.fill")
                        }else{
                            Image(systemName: "suit.heart")
                        }
                    }
                    Button(action: {
                        if(mark){
                            mark = false
                        }else{
                            mark = true
                        }
                    }) {
                        Text("標記地點")
                        if(mark){
                            Image(systemName: "bookmark.fill")
                        }else{
                            Image(systemName: "bookmark")
                        }
                    }
                }
            Spacer()
            if(show){
            Image(systemName: "star.fill")
                .foregroundColor(.yellow)
            }
        }
    }
}
