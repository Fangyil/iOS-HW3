import SwiftUI

struct college: View {
    let colleges = [
        College(Name: "Gryffindor", CName: "葛來分多", Color: "Gryffindor_color", color: "紅色、金色", Founder: "高錐客·葛來分多", Representative: "金獅", Dean: "麥米奈娃", Choose: "勇氣、氣魄、騎士精神"),
        College(Name: "Hufflepuff", CName: "赫夫帕夫", Color: "Hufflepuff_color", color: "黃色、黑色", Founder: "海加‧赫夫帕夫", Representative: "黑獾", Dean: "帕莫娜‧芽菜", Choose: "勤奮耐心、正直忠誠"),
        College(Name: "Ravenclaw", CName: "雷文克勞", Color: "Ravenclaw_color", color: "藍色、青銅色", Founder: "羅威娜·雷文克勞", Representative: "鷹", Dean: "菲力·孚立維", Choose: "聰明、睿智、好奇心"),
        College(Name: "Slytherin", CName: "史萊哲林", Color: "Slytherin_color", color: "綠色、銀色", Founder: "薩拉札·史萊哲林", Representative: "蛇", Dean: "赫瑞司·史拉轟", Choose: "野心、領導、足智多謀")
    ]
    @State private var showSecondViewG = false
    @State private var showSecondViewH = false
    @State private var showSecondViewR = false
    @State private var showSecondViewS = false
    let GlassWidth : CGFloat
    let GlassHeight : CGFloat
    
    var body: some View {
        ZStack{
            Image("Hogwarts_College")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
                .blur(radius: 3)
            VStack{
                Spacer()
                HStack{
                    Glassmorphism(GlassWidth: 180, Glassheight: 300)
                        .overlay {
                            VStack{
                                Image(colleges[0].Name)
                                    .resizable()
                                    .scaledToFit()
                                Button(colleges[0].Name) {
                                     self.showSecondViewG = true
                                 }
                                .foregroundColor(.black)
                                .font(.custom("JMH Mummy Fill", size: 22))
                                .sheet(isPresented: $showSecondViewG) {
                                    College_Detail(Colleges: colleges[0])
                                        .presentationDetents([.height(210)])
                                 }
                            }
                        }
                    Glassmorphism(GlassWidth: 180, Glassheight: 300)
                        .overlay {
                            VStack{
                                Image(colleges[1].Name)
                                    .resizable()
                                    .scaledToFit()
                                Button(colleges[1].Name) {
                                     self.showSecondViewH = true
                                 }
                                .foregroundColor(.black)
                                .font(.custom("JMH Mummy Fill", size: 22))
                                .sheet(isPresented: $showSecondViewH) {
                                    College_Detail(Colleges: colleges[1])
                                        .presentationDetents([.height(210)])
                                 }
                            }
                        }
                }
                Spacer()
                HStack{
                    Glassmorphism(GlassWidth: 180, Glassheight: 300)
                        .overlay {
                            VStack{
                                Image(colleges[2].Name)
                                    .resizable()
                                    .scaledToFit()
                                Button(colleges[2].Name) {
                                     self.showSecondViewR = true
                                 }
                                .foregroundColor(.black)
                                .font(.custom("JMH Mummy Fill", size: 22))
                                .sheet(isPresented: $showSecondViewR) {
                                    College_Detail(Colleges: colleges[2])
                                        .presentationDetents([.height(210)])
                                 }
                            }
                        }
                    Glassmorphism(GlassWidth: 180, Glassheight: 300)
                        .overlay {
                            VStack{
                                Image(colleges[3].Name)
                                    .resizable()
                                    .scaledToFit()
                                Button(colleges[3].Name) {
                                     self.showSecondViewS = true
                                 }
                                .foregroundColor(.black)
                                .font(.custom("JMH Mummy Fill", size: 22))
                                .sheet(isPresented: $showSecondViewS) {
                                    College_Detail(Colleges: colleges[3])
                                        .presentationDetents([.height(210)])
                                 }
                            }
                        }
                }
                Spacer()
            }
        }
    }
}

#Preview {
    college(GlassWidth: 180, GlassHeight: 300)
}
